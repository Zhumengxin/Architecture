/**********************************************************************/
/*   ____  ____                                                       */
/*  /   /\/   /                                                       */
/* /___/  \  /                                                        */
/* \   \   \/                                                       */
/*  \   \        Copyright (c) 2003-2009 Xilinx, Inc.                */
/*  /   /          All Right Reserved.                                 */
/* /---/   /\                                                         */
/* \   \  /  \                                                      */
/*  \___\/\___\                                                    */
/***********************************************************************/

/* This file is designed for use with ISim build 0x7708f090 */

#define XSI_HIDE_SYMBOL_SPEC true
#include "xsi.h"
#include <memory.h>
#ifdef __GNUC__
#include <stdlib.h>
#else
#include <malloc.h>
#define alloca _alloca
#endif
static const char *ng0 = "//Mac/Home/Documents/ARCH/Lab2/srl32.v";
static unsigned int ng1[] = {0U, 0U};



static void Always_9_0(char *t0)
{
    char t4[8];
    char t5[8];
    char t8[8];
    char t27[8];
    char t28[8];
    char *t1;
    char *t2;
    char *t3;
    char *t6;
    char *t7;
    char *t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    unsigned int t14;
    unsigned int t15;
    char *t16;
    unsigned int t17;
    unsigned int t18;
    unsigned int t19;
    unsigned int t20;
    unsigned int t21;
    char *t22;
    char *t23;
    unsigned int t24;
    unsigned int t25;
    unsigned int t26;
    char *t29;
    char *t30;
    char *t31;
    unsigned int t32;
    unsigned int t33;
    unsigned int t34;
    unsigned int t35;
    unsigned int t36;
    unsigned int t37;
    char *t38;
    unsigned int t39;
    unsigned int t40;
    unsigned int t41;
    unsigned int t42;
    char *t43;
    char *t44;
    char *t45;
    char *t46;

LAB0:    t1 = (t0 + 2688U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(9, ng0);
    t2 = (t0 + 3256);
    *((int *)t2) = 1;
    t3 = (t0 + 2720);
    *((char **)t3) = t2;
    *((char **)t1) = &&LAB4;

LAB1:    return;
LAB4:    xsi_set_current_line(9, ng0);

LAB5:    xsi_set_current_line(10, ng0);
    t6 = (t0 + 1208U);
    t7 = *((char **)t6);
    memset(t8, 0, 8);
    t6 = (t8 + 4);
    t9 = (t7 + 4);
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t9);
    t14 = (t13 >> 0);
    t15 = (t14 & 1);
    *((unsigned int *)t6) = t15;
    memset(t5, 0, 8);
    t16 = (t8 + 4);
    t17 = *((unsigned int *)t16);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB6;

LAB7:    if (*((unsigned int *)t16) != 0)
        goto LAB8;

LAB9:    t23 = (t5 + 4);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t23);
    t26 = (t24 || t25);
    if (t26 > 0)
        goto LAB10;

LAB11:    t39 = *((unsigned int *)t5);
    t40 = (~(t39));
    t41 = *((unsigned int *)t23);
    t42 = (t40 || t41);
    if (t42 > 0)
        goto LAB12;

LAB13:    if (*((unsigned int *)t23) > 0)
        goto LAB14;

LAB15:    if (*((unsigned int *)t5) > 0)
        goto LAB16;

LAB17:    memcpy(t4, t44, 8);

LAB18:    t43 = (t0 + 1768);
    xsi_vlogvar_assign_value(t43, t4, 0, 0, 32);
    xsi_set_current_line(11, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t8 + 4);
    t6 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 1);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t6);
    t14 = (t13 >> 1);
    t15 = (t14 & 1);
    *((unsigned int *)t2) = t15;
    memset(t5, 0, 8);
    t7 = (t8 + 4);
    t17 = *((unsigned int *)t7);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB19;

LAB20:    if (*((unsigned int *)t7) != 0)
        goto LAB21;

LAB22:    t16 = (t5 + 4);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t16);
    t26 = (t24 || t25);
    if (t26 > 0)
        goto LAB23;

LAB24:    t39 = *((unsigned int *)t5);
    t40 = (~(t39));
    t41 = *((unsigned int *)t16);
    t42 = (t40 || t41);
    if (t42 > 0)
        goto LAB25;

LAB26:    if (*((unsigned int *)t16) > 0)
        goto LAB27;

LAB28:    if (*((unsigned int *)t5) > 0)
        goto LAB29;

LAB30:    memcpy(t4, t45, 8);

LAB31:    t46 = (t0 + 1768);
    xsi_vlogvar_assign_value(t46, t4, 0, 0, 32);
    xsi_set_current_line(12, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t8 + 4);
    t6 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 2);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t6);
    t14 = (t13 >> 2);
    t15 = (t14 & 1);
    *((unsigned int *)t2) = t15;
    memset(t5, 0, 8);
    t7 = (t8 + 4);
    t17 = *((unsigned int *)t7);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB32;

LAB33:    if (*((unsigned int *)t7) != 0)
        goto LAB34;

LAB35:    t16 = (t5 + 4);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t16);
    t26 = (t24 || t25);
    if (t26 > 0)
        goto LAB36;

LAB37:    t39 = *((unsigned int *)t5);
    t40 = (~(t39));
    t41 = *((unsigned int *)t16);
    t42 = (t40 || t41);
    if (t42 > 0)
        goto LAB38;

LAB39:    if (*((unsigned int *)t16) > 0)
        goto LAB40;

LAB41:    if (*((unsigned int *)t5) > 0)
        goto LAB42;

LAB43:    memcpy(t4, t45, 8);

LAB44:    t46 = (t0 + 1768);
    xsi_vlogvar_assign_value(t46, t4, 0, 0, 32);
    xsi_set_current_line(13, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t8 + 4);
    t6 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 3);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t6);
    t14 = (t13 >> 3);
    t15 = (t14 & 1);
    *((unsigned int *)t2) = t15;
    memset(t5, 0, 8);
    t7 = (t8 + 4);
    t17 = *((unsigned int *)t7);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB45;

LAB46:    if (*((unsigned int *)t7) != 0)
        goto LAB47;

LAB48:    t16 = (t5 + 4);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t16);
    t26 = (t24 || t25);
    if (t26 > 0)
        goto LAB49;

LAB50:    t39 = *((unsigned int *)t5);
    t40 = (~(t39));
    t41 = *((unsigned int *)t16);
    t42 = (t40 || t41);
    if (t42 > 0)
        goto LAB51;

LAB52:    if (*((unsigned int *)t16) > 0)
        goto LAB53;

LAB54:    if (*((unsigned int *)t5) > 0)
        goto LAB55;

LAB56:    memcpy(t4, t45, 8);

LAB57:    t46 = (t0 + 1768);
    xsi_vlogvar_assign_value(t46, t4, 0, 0, 32);
    xsi_set_current_line(14, ng0);
    t2 = (t0 + 1208U);
    t3 = *((char **)t2);
    memset(t8, 0, 8);
    t2 = (t8 + 4);
    t6 = (t3 + 4);
    t10 = *((unsigned int *)t3);
    t11 = (t10 >> 4);
    t12 = (t11 & 1);
    *((unsigned int *)t8) = t12;
    t13 = *((unsigned int *)t6);
    t14 = (t13 >> 4);
    t15 = (t14 & 1);
    *((unsigned int *)t2) = t15;
    memset(t5, 0, 8);
    t7 = (t8 + 4);
    t17 = *((unsigned int *)t7);
    t18 = (~(t17));
    t19 = *((unsigned int *)t8);
    t20 = (t19 & t18);
    t21 = (t20 & 1U);
    if (t21 != 0)
        goto LAB58;

LAB59:    if (*((unsigned int *)t7) != 0)
        goto LAB60;

LAB61:    t16 = (t5 + 4);
    t24 = *((unsigned int *)t5);
    t25 = *((unsigned int *)t16);
    t26 = (t24 || t25);
    if (t26 > 0)
        goto LAB62;

LAB63:    t39 = *((unsigned int *)t5);
    t40 = (~(t39));
    t41 = *((unsigned int *)t16);
    t42 = (t40 || t41);
    if (t42 > 0)
        goto LAB64;

LAB65:    if (*((unsigned int *)t16) > 0)
        goto LAB66;

LAB67:    if (*((unsigned int *)t5) > 0)
        goto LAB68;

LAB69:    memcpy(t4, t45, 8);

LAB70:    t46 = (t0 + 1768);
    xsi_vlogvar_assign_value(t46, t4, 0, 0, 32);
    goto LAB2;

LAB6:    *((unsigned int *)t5) = 1;
    goto LAB9;

LAB8:    t22 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t22) = 1;
    goto LAB9;

LAB10:    t29 = (t0 + 1048U);
    t30 = *((char **)t29);
    memset(t28, 0, 8);
    t29 = (t28 + 4);
    t31 = (t30 + 4);
    t32 = *((unsigned int *)t30);
    t33 = (t32 >> 1);
    *((unsigned int *)t28) = t33;
    t34 = *((unsigned int *)t31);
    t35 = (t34 >> 1);
    *((unsigned int *)t29) = t35;
    t36 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t36 & 2147483647U);
    t37 = *((unsigned int *)t29);
    *((unsigned int *)t29) = (t37 & 2147483647U);
    t38 = ((char*)((ng1)));
    xsi_vlogtype_concat(t27, 32, 32, 2U, t38, 1, t28, 31);
    goto LAB11;

LAB12:    t43 = (t0 + 1048U);
    t44 = *((char **)t43);
    goto LAB13;

LAB14:    xsi_vlog_unsigned_bit_combine(t4, 32, t27, 32, t44, 32);
    goto LAB18;

LAB16:    memcpy(t4, t27, 8);
    goto LAB18;

LAB19:    *((unsigned int *)t5) = 1;
    goto LAB22;

LAB21:    t9 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB22;

LAB23:    t22 = (t0 + 1768);
    t23 = (t22 + 56U);
    t29 = *((char **)t23);
    memset(t28, 0, 8);
    t30 = (t28 + 4);
    t31 = (t29 + 4);
    t32 = *((unsigned int *)t29);
    t33 = (t32 >> 2);
    *((unsigned int *)t28) = t33;
    t34 = *((unsigned int *)t31);
    t35 = (t34 >> 2);
    *((unsigned int *)t30) = t35;
    t36 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t36 & 1073741823U);
    t37 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t37 & 1073741823U);
    t38 = ((char*)((ng1)));
    xsi_vlogtype_concat(t27, 32, 32, 2U, t38, 2, t28, 30);
    goto LAB24;

LAB25:    t43 = (t0 + 1768);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    goto LAB26;

LAB27:    xsi_vlog_unsigned_bit_combine(t4, 32, t27, 32, t45, 32);
    goto LAB31;

LAB29:    memcpy(t4, t27, 8);
    goto LAB31;

LAB32:    *((unsigned int *)t5) = 1;
    goto LAB35;

LAB34:    t9 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB35;

LAB36:    t22 = (t0 + 1768);
    t23 = (t22 + 56U);
    t29 = *((char **)t23);
    memset(t28, 0, 8);
    t30 = (t28 + 4);
    t31 = (t29 + 4);
    t32 = *((unsigned int *)t29);
    t33 = (t32 >> 4);
    *((unsigned int *)t28) = t33;
    t34 = *((unsigned int *)t31);
    t35 = (t34 >> 4);
    *((unsigned int *)t30) = t35;
    t36 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t36 & 268435455U);
    t37 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t37 & 268435455U);
    t38 = ((char*)((ng1)));
    xsi_vlogtype_concat(t27, 32, 32, 2U, t38, 4, t28, 28);
    goto LAB37;

LAB38:    t43 = (t0 + 1768);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    goto LAB39;

LAB40:    xsi_vlog_unsigned_bit_combine(t4, 32, t27, 32, t45, 32);
    goto LAB44;

LAB42:    memcpy(t4, t27, 8);
    goto LAB44;

LAB45:    *((unsigned int *)t5) = 1;
    goto LAB48;

LAB47:    t9 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB48;

LAB49:    t22 = (t0 + 1768);
    t23 = (t22 + 56U);
    t29 = *((char **)t23);
    memset(t28, 0, 8);
    t30 = (t28 + 4);
    t31 = (t29 + 4);
    t32 = *((unsigned int *)t29);
    t33 = (t32 >> 8);
    *((unsigned int *)t28) = t33;
    t34 = *((unsigned int *)t31);
    t35 = (t34 >> 8);
    *((unsigned int *)t30) = t35;
    t36 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t36 & 16777215U);
    t37 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t37 & 16777215U);
    t38 = ((char*)((ng1)));
    xsi_vlogtype_concat(t27, 32, 32, 2U, t38, 8, t28, 24);
    goto LAB50;

LAB51:    t43 = (t0 + 1768);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    goto LAB52;

LAB53:    xsi_vlog_unsigned_bit_combine(t4, 32, t27, 32, t45, 32);
    goto LAB57;

LAB55:    memcpy(t4, t27, 8);
    goto LAB57;

LAB58:    *((unsigned int *)t5) = 1;
    goto LAB61;

LAB60:    t9 = (t5 + 4);
    *((unsigned int *)t5) = 1;
    *((unsigned int *)t9) = 1;
    goto LAB61;

LAB62:    t22 = (t0 + 1768);
    t23 = (t22 + 56U);
    t29 = *((char **)t23);
    memset(t28, 0, 8);
    t30 = (t28 + 4);
    t31 = (t29 + 4);
    t32 = *((unsigned int *)t29);
    t33 = (t32 >> 16);
    *((unsigned int *)t28) = t33;
    t34 = *((unsigned int *)t31);
    t35 = (t34 >> 16);
    *((unsigned int *)t30) = t35;
    t36 = *((unsigned int *)t28);
    *((unsigned int *)t28) = (t36 & 65535U);
    t37 = *((unsigned int *)t30);
    *((unsigned int *)t30) = (t37 & 65535U);
    t38 = ((char*)((ng1)));
    xsi_vlogtype_concat(t27, 32, 32, 2U, t38, 16, t28, 16);
    goto LAB63;

LAB64:    t43 = (t0 + 1768);
    t44 = (t43 + 56U);
    t45 = *((char **)t44);
    goto LAB65;

LAB66:    xsi_vlog_unsigned_bit_combine(t4, 32, t27, 32, t45, 32);
    goto LAB70;

LAB68:    memcpy(t4, t27, 8);
    goto LAB70;

}

static void Cont_17_1(char *t0)
{
    char t3[8];
    char *t1;
    char *t2;
    char *t4;
    char *t5;
    char *t6;
    char *t7;
    unsigned int t8;
    unsigned int t9;
    unsigned int t10;
    unsigned int t11;
    unsigned int t12;
    unsigned int t13;
    char *t14;
    char *t15;
    char *t16;
    char *t17;
    char *t18;
    char *t19;

LAB0:    t1 = (t0 + 2936U);
    t2 = *((char **)t1);
    if (t2 == 0)
        goto LAB2;

LAB3:    goto *t2;

LAB2:    xsi_set_current_line(17, ng0);
    t2 = (t0 + 1768);
    t4 = (t2 + 56U);
    t5 = *((char **)t4);
    memset(t3, 0, 8);
    t6 = (t3 + 4);
    t7 = (t5 + 4);
    t8 = *((unsigned int *)t5);
    t9 = (t8 >> 0);
    *((unsigned int *)t3) = t9;
    t10 = *((unsigned int *)t7);
    t11 = (t10 >> 0);
    *((unsigned int *)t6) = t11;
    t12 = *((unsigned int *)t3);
    *((unsigned int *)t3) = (t12 & 4294967295U);
    t13 = *((unsigned int *)t6);
    *((unsigned int *)t6) = (t13 & 4294967295U);
    t14 = (t0 + 3352);
    t15 = (t14 + 56U);
    t16 = *((char **)t15);
    t17 = (t16 + 56U);
    t18 = *((char **)t17);
    memcpy(t18, t3, 8);
    xsi_driver_vfirst_trans(t14, 0, 31);
    t19 = (t0 + 3272);
    *((int *)t19) = 1;

LAB1:    return;
}


extern void work_m_00000000003400178831_3402988428_init()
{
	static char *pe[] = {(void *)Always_9_0,(void *)Cont_17_1};
	xsi_register_didat("work_m_00000000003400178831_3402988428", "isim/test_isim_beh.exe.sim/work/m_00000000003400178831_3402988428.didat");
	xsi_register_executes(pe);
}
